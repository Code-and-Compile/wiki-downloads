# ThingsBoard AI motor example project

Use these files to inspect or reuse the configuration from **From Prompt to Live Dashboard with ThingsBoard AI**. To learn the AI workflow, follow the guide's five prompt-based steps; importing a dashboard is a separate reuse option, not AI generation.

The motor and vibration readings are simulated in Node-RED. No physical motor, sensor or predictive-maintenance model is included.

## What is included

| File | Purpose |
| --- | --- |
| `node-red/industrial-motor-cloud-flow.json` | Complete Node-RED flow with the unchanged simulator Function, five-second interval and verified TLS defaults. |
| `thingsboard/motor-overview-ai.json` | Native AI-generated dashboard export with only its source-device alias made portable. |
| `thingsboard/alarm-rules/motor_fault.json` | Motor Fault alarm definition. |
| `thingsboard/alarm-rules/high_vibration.json` | High Vibration definition, including Warning and Critical conditions. |
| `thingsboard/alarm-rules/high_temperature.json` | High Temperature alarm definition. |

No device token, password, browser session, tenant login, telemetry history or active alarm records are included. This is not a complete tenant backup.

## Before importing

Use a ThingsBoard Cloud EU tenant with the required dashboard, alarm-rule and AI features and working allowances. Check **API usage**. Install Node-RED using the [official installation guide](https://nodered.org/docs/getting-started/).

Keep the local simulator stopped while configuring the project. Do not import duplicate copies of existing devices, dashboards or matching alarm rules.

## 1. Select your motor device

Use the motor device created by the guide's first AI prompt, normally **Industrial Motor 01**. The files do not create a device or copy its credentials. If reusing the project without the AI walkthrough, create/select an appropriate device in your own tenant first.

## 2. Import and retarget the dashboard

Use **Dashboards → Add dashboard → Import dashboard** and select `thingsboard/motor-overview-ai.json`.

The original export used a fixed device UUID. For distribution, only that alias's filter has been replaced with a device-name filter for **Industrial Motor 01**. The widget configuration, internal alias references, layout, time window and AI metadata are otherwise unchanged. The original tenant's device UUID is not in this portable copy.

**Always check the alias after import.** Open the dashboard in Edit mode, open **Entity aliases**, and inspect **Industrial Motor**. Select your exact motor device using a Single entity filter if needed, then save. A name filter matches a prefix; similarly named devices can be ambiguous. See the official [entity-filter reference](https://thingsboard.io/docs/reference/data-query-api/#entityname).

Confirm that every widget and the Alarms Table use the same intended motor alias. Blank widgets before the local publisher starts are not proof of an import failure. Example readings inserted during solution installation are not proof of live telemetry.

## 3. Import and target the alarm definitions

These are native **alarm-rule definitions**, not rule chains or active alarm records. They preserve their exported conditions and `aiGenerated` metadata. They do not contain a device or profile target binding.

If your ThingsBoard version supports importing these alarm definitions, use its alarm-rule import action and select your own target device or device profile. Check the scope before saving: a profile-level rule can affect other devices using that profile. Reuse matching rules instead of adding duplicates. If the import format is not supported, use Step 5's AI prompt in the guide and compare its proposed conditions with these files.

| Alarm | Trigger | Clear |
| --- | --- | --- |
| Motor Fault | `fault=true` → Critical | `fault=false` |
| High Vibration | `vibrationRms >7` and `<=9` → Warning; `>9` → Critical | `vibrationRms <=7` |
| High Temperature | `temperature >30` → Warning | `temperature <=30` |

The conditions use latest telemetry and an always-active schedule. These are simulation thresholds, not safe operating limits for a real motor. Confirm severity, target, clear conditions and missing-data behaviour in your destination tenant before relying on alarms. No notification actions are included.

## 4. Configure Node-RED securely

Import `node-red/industrial-motor-cloud-flow.json` once. It already contains the full simulator Function; no separate simulator code needs adding.

The imported flow is already configured for secure MQTT. Open **Publish to ThingsBoard Cloud EU**, check the settings below and enter your own device token as the username:

| Setting | Value |
| --- | --- |
| Broker | `mqtt.eu.thingsboard.cloud` |
| Port | `8883` |
| TLS | Enabled, with server certificate verification enabled |
| Username | Your own motor device access token, entered locally |
| Password | Blank |
| Telemetry topic | `v1/devices/me/telemetry` |
| QoS / retain | `1` / `false` |

Never disable certificate verification. Never add the private token to this ZIP, a public flow export, a screenshot or source control.

## 5. Record, verify and stop

Enable the five-second Inject only when ready to check the demo. Confirm advancing timestamps in Latest telemetry, then briefly pause/restart the local publisher to check that readings come from your PC. The unchanged Function advances one simulation tick per message; its runtime and energy counters are illustrative, not calibrated real-world measurements.

The dashboard's global **last 1 minute** window is suitable for a short recording but also limits displayed alarm history. Choose a longer global window to review older alarms. The AI workflow does not configure an independent Alarms Table time window.

**Stop immediately after recording:** disable the simulation's Inject node and Deploy. Closing the dashboard does not stop Node-RED. Leave publishing stopped between recordings to conserve telemetry and storage allowance.

## What packaging checks do and do not prove

The bundle builder checks JSON syntax, the secure five-second flow's exact bytes, unchanged alarm definitions and AI metadata, the documented alarm thresholds, the dashboard's alias-only portability change, and common credential/token indicators. It does not launch Node-RED, import these files into a Cloud tenant or test alarm activation/clearing. Repeat the guide's checks in your own environment.

AI-generated layouts can vary. Exact font sizes, automatic text scaling, title-bar styling and an analogue needle gauge are optional manual refinements, not requirements reproduced by these AI prompts.
