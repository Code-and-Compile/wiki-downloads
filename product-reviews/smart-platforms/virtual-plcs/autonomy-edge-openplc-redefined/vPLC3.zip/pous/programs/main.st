PROGRAM main
VAR
	wX_VRMSHighWord : uint AT %IW1;
	wX_VRMSLowWord : uint AT %IW2;
	wY_VRMSHighWord : uint AT %IW3;
	wY_VRMSLowWord : uint AT %IW4;
	wZ_VRMSHighWord : uint AT %IW5;
	wZ_VRMSLowWord : uint AT %IW6;
	wTempHighWord : uint AT %IW7;
	wTempLowWord : uint AT %IW8;
	wSensor : word AT %IW0;
	wSmartLightState : word AT %QW0;
	wMode : word AT %QW1;
	wSeg1 : word AT %QW3;
	wSeg2 : word AT %QW4;
	wSeg3 : word AT %QW5;
	wSeg4 : word AT %QW6;
	wSeg5 : word AT %QW7;
	rTemp : real;
	rX_VRMS : real;
	rY_VRMS : real;
	rZ_VRMS : real;
	WtoR_convert : WTOR;
	iVibrationState : int;
	rThresholdL : real;
	rThresholdH : real;
	rMaxVib : real;
END_VAR
//Initialized values
wSmartLightState  := 1;
wMode := 34049;
rThresholdH := 7.1;
rThresholdL := 2.5;

(* Temperature *)
WtoR_convert(HighWord := wTempHighWord, LowWord := wTempLowWord);
rTemp := WtoR_convert.RealOut;

(* X_VRMS *)
WtoR_convert(HighWord := wX_VRMSHighWord, LowWord := wX_VRMSLowWord);
rX_VRMS := WtoR_convert.RealOut;

(* Y_VRMS *)
WtoR_convert(HighWord := wY_VRMSHighWord, LowWord := wY_VRMSLowWord);
rY_VRMS := WtoR_convert.RealOut;

(* Z_VRMS *)
WtoR_convert(HighWord := wZ_VRMSHighWord, LowWord := wZ_VRMSLowWord);
rZ_VRMS := WtoR_convert.RealOut;

//Finding max Vib
(* Find max vibration *)
rMaxVib := rX_VRMS;

IF rY_VRMS > rMaxVib THEN
    rMaxVib := rY_VRMS;
END_IF;

IF rZ_VRMS > rMaxVib THEN
    rMaxVib := rZ_VRMS;
END_IF;

//Classify State
(* Classify state *)
IF rMaxVib < rThresholdL THEN
    iVibrationState := 0;

ELSIF rMaxVib > rThresholdL and rMaxVib < rThresholdH THEN
    iVibrationState := 1;

ELSE
    iVibrationState := 2;
END_IF;


IF wSensor = 1 THEN
CASE iVibrationState OF
    2: // Red Triple strobe - High vibration
    wSeg1 := 261;
    wSeg2 := 261;
    wSeg3 := 261;
    wSeg4 := 261;
    wSeg5 := 261;

    1: // Orange Rotating effect - Moderate vibration
    wSeg1 := 2055;
    wSeg2 := 2055;
    wSeg3 := 2055;
    wSeg4 := 2055;
    wSeg5 := 2055;

    ELSE // Green Stable - Low vibration 
    wSeg1 := 512;
    wSeg2 := 512;
    wSeg3 := 512;
    wSeg4 := 512;
    wSeg5 := 512;

END_CASE;

ELSE //White color, No object present
    wSeg1 := 2304;
    wSeg2 := 2304;
    wSeg3 := 2304;
    wSeg4 := 2304;
    wSeg5 := 2304;

END_IF;
END_PROGRAM