FUNCTION_BLOCK WtoR
VAR_INPUT
	HighWord : uint;
	LowWord : uint;
END_VAR

VAR_OUTPUT
	RealOut : real;
END_VAR
/* ================================================================
 *  C/C++ FUNCTION BLOCK
 *
 *  ---------------------------------------------------------------
 *  - This function block runs **in sync** with the PLC runtime.
 *  - The `setup()` function is called once when the block initializes.
 *  - The `loop()` function is called at every PLC scan cycle.
 *  - Block input and output variables declared in the variable table
 *    can be accessed directly by name in this C/C++ code.
 *
 *  This block executes as part of the main PLC process and follows
 *  the configured scan time in the Resources. Use it for real-time
 *  control logic, fast I/O operations, or any C-based algorithms.
 * ================================================================ */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

void plc_log(char *msg);

int wtor_cycle_count = 0;

void setup()
{

}

void loop()
{
    uint16_t combined_array[2];
    float converted_val = 0;
    char print_msg[1000];

    uint8_t b[4];
    uint32_t u32;

    b[0] = (uint8_t)(HighWord & 0xFF);   // B = Low byte  of Register 1 (HighWord)
    b[1] = (uint8_t)(HighWord >> 8);     // A = High byte of Register 1 (HighWord)
    b[2] = (uint8_t)(LowWord  & 0xFF);   // D = Low byte  of Register 2 (LowWord)
    b[3] = (uint8_t)(LowWord  >> 8);     // C = High byte of Register 2 (LowWord)

    // placing each byte into its correct slot BADC,  b[0]=B, b[1]=A, b[2]=D, b[3]=C
    u32 = ((uint32_t)b[0] << 24) |
          ((uint32_t)b[1] << 16) |
          ((uint32_t)b[2] << 8)  |
          ((uint32_t)b[3]);

    memcpy(&RealOut, &u32, sizeof(RealOut));
    //u32 bytes = [ b0  b1  b2  b3 ] = [ B  A  D  C ]

    // Debug logs (print once every 100 cycles to avoid flooding the logs)
    if (wtor_cycle_count == 100)
    {
        sprintf(print_msg, "Low word: %02x", LowWord);
        plc_log(print_msg);
        sprintf(print_msg, "High word: %02x", HighWord);
        plc_log(print_msg);
        sprintf(print_msg, "Converted value: %f", RealOut);
        plc_log(print_msg);

        wtor_cycle_count = 0;
    }
    else
    {
        wtor_cycle_count++;
    }

}
END_FUNCTION_BLOCK