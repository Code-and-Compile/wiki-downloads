FUNCTION_BLOCK print_logs
VAR_INPUT
	print_message : bool;
	content : string;
END_VAR
/* ================================================================
 *  C/C++ FUNCTION BLOCK
 *
 *  ---------------------------------------------------------------
 *  - This function block runs **in sync** with the PLC runtime.
 *  - The `setup()` function is called once when the block initializes.
 *  - The `loop()` function is called at every PLC scan cycle.
 *  - Block input and output variables declared in the variable table
 *    can be accessed directly by name in this C/C++ code.
 *
 *  This block executes as part of the main PLC process and follows
 *  the configured scan time in the Resources. Use it for real-time
 *  control logic, fast I/O operations, or any C-based algorithms.
 * ================================================================ */

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

// These includes are only required by the plc_log function
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <time.h>

int log_fd = -1;
bool previous_print_msg = false;

/* ================================================================
 *  Utility function to print messages on the PLC Logs.
 * ================================================================ 
 */

void plc_log(char *msg) 
{
    if (log_fd < 0) 
    {
        struct sockaddr_un addr;
        log_fd = socket(AF_UNIX, SOCK_STREAM, 0);
        if (log_fd < 0) return;
        memset(&addr, 0, sizeof(addr));
        addr.sun_family = AF_UNIX;
        strncpy(addr.sun_path, "/run/runtime/log_runtime.socket",
                sizeof(addr.sun_path) - 1);
        if (connect(log_fd, (struct sockaddr *)&addr, sizeof(addr)) == -1) 
        {
            close(log_fd);
            log_fd = -1;
            return;
        }
    }
    char buf[512];
    snprintf(buf, sizeof(buf),
        "{\"timestamp\":\"%ld\",\"level\":\"INFO\",\"message\":\"%s\"}\n",
        (long)time(NULL), msg);
    if (write(log_fd, buf, strlen(buf)) == -1) 
    {
        close(log_fd);
        log_fd = -1;
    }
}

void setup()
{


}

void loop()
{
    if ((previous_print_msg == false) && (print_message == true))
    {
        plc_log((char *)content.body);
    }

    previous_print_msg = print_message;
}
END_FUNCTION_BLOCK