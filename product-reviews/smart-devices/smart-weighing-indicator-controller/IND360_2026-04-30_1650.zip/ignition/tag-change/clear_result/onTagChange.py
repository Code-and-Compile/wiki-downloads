def onTagChange(initialChange, newValue, previousValue, event, executionCount):
	
    # Get raw IND360 timestamp e.g. "2026-04-28T11:45:41.000Z"
    raw_timestamp = str(newValue.value)

    # Convert ISO 8601 format to SQLite compatible format
    # Replace the T separator with a space and remove the Z suffix
    clean_timestamp = raw_timestamp.replace("T", " ").replace("Z", "")
    # Result: "2026-04-28 11:45:41.000" 

    # Read result fields from MQTT Engine tags
    description = system.tag.readBlocking([
        "[MQTT Engine]IND360_folder/ind360/devices/C249346600/commands/tare-clear/result/content/description"
    ])[0].value

    code = system.tag.readBlocking([
        "[MQTT Engine]IND360_folder/ind360/devices/C249346600/commands/tare-clear/result/code"
    ])[0].value

    correlation = system.tag.readBlocking([
        "[MQTT Engine]IND360_folder/ind360/devices/C249346600/commands/tare-clear/result/_correlation"
    ])[0].value

    # Log to database with cleaned SQLite compatible timestamp
    system.db.runPrepUpdate(
        "INSERT INTO ind360_command_log (command, result, timestamp) VALUES (?, ?, ?)",
        ["clear", description, clean_timestamp],
        database="Sample_SQLite_Database"
    )